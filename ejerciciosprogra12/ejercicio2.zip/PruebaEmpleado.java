public class PruebaEmpleado {
    public static void main(String[] args) {

        Empleado emp1 = new Empleado("Juan", "Perez", 500);
        Empleado emp2 = new Empleado("Maria", "Lopez", 800);

        // Salario anual
        System.out.println(emp1.getNombre() + " salario anual: " + (emp1.getSalario() * 12));
        System.out.println(emp2.getNombre() + " salario anual: " + (emp2.getSalario() * 12));

        // Aumento del 10%
        emp1.setSalario(emp1.getSalario() * 1.10);
        emp2.setSalario(emp2.getSalario() * 1.10);

        System.out.println("Después del aumento:");

        System.out.println(emp1.getNombre() + " salario anual: " + (emp1.getSalario() * 12));
        System.out.println(emp2.getNombre() + " salario anual: " + (emp2.getSalario() * 12));
    }
}