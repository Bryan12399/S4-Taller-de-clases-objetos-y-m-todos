public class PruebaFecha {
    public static void main(String[] args) {

        Fecha fecha1 = new Fecha(4, 26, 2026);

        fecha1.mostrarFecha();

        fecha1.setMes(12);
        fecha1.setDia(25);
        fecha1.setAnio(2025);

        fecha1.mostrarFecha();
    }
}